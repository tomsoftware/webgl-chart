export interface GpuBuffer {
    get data(): AllowSharedBufferSource;
    clear(): void;
    get length(): number;
    get count(): number;
    get dataVersion(): number;
    bindBuffer(gl: WebGLRenderingContext, variableLoc: GLint): void;
}
